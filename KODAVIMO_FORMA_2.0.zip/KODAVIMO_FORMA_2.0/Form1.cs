﻿using System.Security.Cryptography;

namespace KODAVIMO_FORMA_2._0
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void close_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void encrypt_Click(object sender, EventArgs e)
        {
            string password = slaptikas.Text;

            if (!string.IsNullOrEmpty(password))
            {
                FileEncryptAES("informacija.txt", password);
                FileEncrypt3DES("informacija.txt", password);
                MessageBox.Show("Sėkmingai užkoduota!");
            }
            else
            {
                MessageBox.Show("Įveskite slaptažodį!");
            }
        }

        private void decrypt_Click(object sender, EventArgs e)
        {
            string password = slaptikas.Text;

            if (!string.IsNullOrEmpty(password))
            {
                FileDecryptAES("informacija.txt.aes", "issifruotas_AES.txt", password);
                FileDecrypt3DES("informacija.txt.3des", "issifruotas_3DES.txt", password);
                MessageBox.Show("Sėkmingai atkoduota!");
            }
            else
            {
                MessageBox.Show("Įveskite slaptažodį!");
            }
        }

        private static byte[] GenerateRandomSalt()
        {
            byte[] data = new byte[32];

            using (RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider())
            {
                for (int i = 0; i < 10; i++)
                {
                    rng.GetBytes(data);
                }
            }

            return data;
        }

        private void FileEncryptAES(string inputFile, string password)
        {
            byte[] salt = GenerateRandomSalt();

            using (FileStream fsCrypt = new FileStream(inputFile + ".aes", FileMode.Create))
            {
                byte[] passwordBytes = System.Text.Encoding.UTF8.GetBytes(password);
                using (RijndaelManaged AES = new RijndaelManaged())
                {
                    AES.KeySize = 256;
                    AES.BlockSize = 128;
                    AES.Padding = PaddingMode.PKCS7;
                    var key = new Rfc2898DeriveBytes(passwordBytes, salt, 50000);
                    AES.Key = key.GetBytes(AES.KeySize / 8);
                    AES.IV = key.GetBytes(AES.BlockSize / 8);
                    AES.Mode = CipherMode.CBC;

                    fsCrypt.Write(salt, 0, salt.Length);
                    using (CryptoStream cs = new CryptoStream(fsCrypt, AES.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        using (FileStream fsIn = new FileStream(inputFile, FileMode.Open))
                        {
                            byte[] buffer = new byte[1048576];
                            int read;
                            try
                            {
                                while ((read = fsIn.Read(buffer, 0, buffer.Length)) > 0)
                                {
                                    cs.Write(buffer, 0, read);
                                }
                                fsIn.Close();
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine("Nepavyko: " + ex.Message);
                            }
                        }
                    }
                }
            }

        }

        private void FileDecryptAES(string inputFile, string outputFile, string password)
        {
            byte[] passwordBytes = System.Text.Encoding.UTF8.GetBytes(password);
            byte[] salt = new byte[32];

            using (FileStream fsCrypt = new FileStream(inputFile, FileMode.Open))
            {
                fsCrypt.Read(salt, 0, salt.Length);

                using (RijndaelManaged AES = new RijndaelManaged())
                {
                    AES.KeySize = 256;
                    AES.BlockSize = 128;
                    var key = new Rfc2898DeriveBytes(passwordBytes, salt, 50000);
                    AES.Key = key.GetBytes(AES.KeySize / 8);
                    AES.IV = key.GetBytes(AES.BlockSize / 8);
                    AES.Padding = PaddingMode.PKCS7;
                    AES.Mode = CipherMode.CBC;

                    using (CryptoStream cs = new CryptoStream(fsCrypt, AES.CreateDecryptor(), CryptoStreamMode.Read))
                    {
                        using (FileStream fsOut = new FileStream(outputFile, FileMode.Create))
                        {
                            int read;
                            byte[] buffer = new byte[1048576];

                            try
                            {
                                while ((read = cs.Read(buffer, 0, buffer.Length)) > 0)
                                {
                                    fsOut.Write(buffer, 0, read);
                                }
                            }
                            catch (CryptographicException ex_CryptographicException)
                            {
                                Console.WriteLine("Nepavyko " + ex_CryptographicException.Message);
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine("Nepavyko " + ex.Message);
                            }

                            try
                            {
                                cs.Close();
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine("Nepavyko: " + ex.Message);
                            }
                        }
                    }
                }
            }

        }

        private void FileEncrypt3DES(string inputFile, string password)
        {
            byte[] salt = GenerateRandomSalt();

            using (FileStream fsCrypt = new FileStream(inputFile + ".3des", FileMode.Create))
            {
                byte[] passwordBytes = System.Text.Encoding.UTF8.GetBytes(password);
                using (TripleDESCryptoServiceProvider DES = new TripleDESCryptoServiceProvider())
                {
                    DES.KeySize = 192;
                    DES.BlockSize = 64;
                    DES.Padding = PaddingMode.PKCS7;
                    var key = new Rfc2898DeriveBytes(passwordBytes, salt, 50000);
                    DES.Key = key.GetBytes(DES.KeySize / 8);
                    DES.IV = key.GetBytes(DES.BlockSize / 8);
                    DES.Mode = CipherMode.CBC;

                    fsCrypt.Write(salt, 0, salt.Length);
                    using (CryptoStream cs = new CryptoStream(fsCrypt, DES.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        using (FileStream fsIn = new FileStream(inputFile, FileMode.Open))
                        {
                            byte[] buffer = new byte[1048576];
                            int read;
                            try
                            {
                                while ((read = fsIn.Read(buffer, 0, buffer.Length)) > 0)
                                {
                                    cs.Write(buffer, 0, read);
                                }
                                fsIn.Close();
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine("Nepavyko: " + ex.Message);
                            }
                        }
                    }
                }
            }
        }

        private void FileDecrypt3DES(string inputFile, string outputFile, string password)
        {
            byte[] passwordBytes = System.Text.Encoding.UTF8.GetBytes(password);
            byte[] salt = new byte[32];

            using (FileStream fsCrypt = new FileStream(inputFile, FileMode.Open))
            {
                fsCrypt.Read(salt, 0, salt.Length);

                using (TripleDESCryptoServiceProvider DES = new TripleDESCryptoServiceProvider())
                {
                    DES.KeySize = 192;
                    DES.BlockSize = 64;
                    var key = new Rfc2898DeriveBytes(passwordBytes, salt, 50000);
                    DES.Key = key.GetBytes(DES.KeySize / 8);
                    DES.IV = key.GetBytes(DES.BlockSize / 8);
                    DES.Padding = PaddingMode.PKCS7;
                    DES.Mode = CipherMode.CBC;

                    using (CryptoStream cs = new CryptoStream(fsCrypt, DES.CreateDecryptor(), CryptoStreamMode.Read))
                    {
                        using (FileStream fsOut = new FileStream(outputFile, FileMode.Create))
                        {
                            int read;
                            byte[] buffer = new byte[1048576];

                            try
                            {
                                while ((read = cs.Read(buffer, 0, buffer.Length)) > 0)
                                {
                                    fsOut.Write(buffer, 0, read);
                                }
                            }
                            catch (CryptographicException ex_CryptographicException)
                            {
                                Console.WriteLine("Nepavyko " + ex_CryptographicException.Message);
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine("Nepavyko " + ex.Message);
                            }

                            try
                            {
                                cs.Close();
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine("Nepavyko: " + ex.Message);
                            }
                        }
                    }
                }
            }
        }
    }
}
