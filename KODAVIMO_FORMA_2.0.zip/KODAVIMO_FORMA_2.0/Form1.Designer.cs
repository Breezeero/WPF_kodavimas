﻿namespace KODAVIMO_FORMA_2._0
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            slaptikas = new TextBox();
            encrypt = new Button();
            decrypt = new Button();
            close = new Button();
            SuspendLayout();
            // 
            // slaptikas
            // 
            slaptikas.Location = new Point(57, 57);
            slaptikas.Name = "slaptikas";
            slaptikas.Size = new Size(304, 27);
            slaptikas.TabIndex = 0;
            slaptikas.Text = "Įveskite slaptažodį";
            // 
            // encrypt
            // 
            encrypt.Location = new Point(93, 108);
            encrypt.Name = "encrypt";
            encrypt.Size = new Size(94, 29);
            encrypt.TabIndex = 1;
            encrypt.Text = "Uzkoduoti";
            encrypt.UseVisualStyleBackColor = true;
            encrypt.Click += encrypt_Click;
            // 
            // decrypt
            // 
            decrypt.Location = new Point(225, 108);
            decrypt.Name = "decrypt";
            decrypt.Size = new Size(94, 29);
            decrypt.TabIndex = 2;
            decrypt.Text = "Atkoduoti";
            decrypt.UseVisualStyleBackColor = true;
            decrypt.Click += decrypt_Click;
            // 
            // close
            // 
            close.Location = new Point(319, 165);
            close.Name = "close";
            close.Size = new Size(94, 29);
            close.TabIndex = 3;
            close.Text = "Išeiti";
            close.UseVisualStyleBackColor = true;
            close.Click += close_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(425, 206);
            Controls.Add(close);
            Controls.Add(decrypt);
            Controls.Add(encrypt);
            Controls.Add(slaptikas);
            Name = "Form1";
            Text = "Kodavimas";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox slaptikas;
        private Button encrypt;
        private Button decrypt;
        private Button close;
    }
}
